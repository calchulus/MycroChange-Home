A Pen created at CodePen.io. You can find this one at http://codepen.io/robooneus/pen/Aclqr.

 A simple, animated down arrow to indicate scroll intent. More info at <a href="http://www.robsawyer.me/blog/2013/09/17/scroll-indicator/">robsawyer.me</a>